# Hackathon Challenge: Suspicious Login

## Challenge Description

Our boss calls us at 5 PM on Friday. Hooray! But the topic is quite urgent. Some people have noticed a lot of suspicious activity happening in our system, and we need to identify which user accounts may have been compromised.

Unfortunately, the login database is quite large, but luckily it only has three columns: Time, User, and PasswordResultHash.

Let's dig into the investigation. After a brief manual review of the table, it's obvious that we need to automate this task with our favorite weapon of choice: PowerShell.

## How to Detect a Compromised Account

A login attempt is considered failed when the PasswordResultHash is below 100,000. However, this does not necessarily mean the account is compromised.

An account is considered compromised if the user has made three consecutive failed login attempts without any successful attempts.

Additionally, if a user has logged in successfully two or more times at the exact same moment, the account is considered compromised.

## Tasks to Accomplish

1. Identify all accounts that have been compromised based on the given criteria.
2. Determine the total number of compromised and un-compromised accounts.
3. Notify the compromised accounts of users who are scheduled to work on Saturday that they do not have to work tomorrow. Find these users in the 'UserDatabase.csv' file.

## Challenge Categories

Solve the challenge
You can participate in those categories:

- Performance Matters: Try to achieve the goal in the shortest time possible.
- Size Matters: Let's play code golf and try to solve the challenge using the fewest characters of code possible.
- Code Style: Make your code robust, smart, and/or elegant.

You can participate in as many categories as you like.
